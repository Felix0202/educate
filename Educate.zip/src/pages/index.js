import Header from '../components/header';

export default function Home() {
  return (
    <>
      <Header></Header>
        <div>
            <h2>About site</h2>
            <br/><br/><br/>
            <h1>this site is currently in development!</h1>
        </div>
    </>
  )
}
